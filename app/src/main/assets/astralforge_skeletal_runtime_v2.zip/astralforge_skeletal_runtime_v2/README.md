# Astral Forge Skeletal Rigs v2

Production-tuned prototype pass for the new Astral Forge battle actors.

Changes from v1:
- corrected obvious bad automatic part assignments
- switched Mage, Ranger, Rogue, and Paladin to hybrid cutout rigs where needed
- corrected Dire Wolf jaw, ears, limb groups, and tail chain
- assembled a dedicated Astral Warden boss weapon
- removed bogus shield/hand assignments from several classes
- added class-specific attack timings
- added secondary cape/hair movement hooks
- standardized 1000x1000 virtual rig space for Android
- preserved source sheets alongside final cutout pieces

This package is ready for the next step: Android skeletal renderer integration.
